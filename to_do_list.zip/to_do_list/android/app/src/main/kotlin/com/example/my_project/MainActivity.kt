package com.mycompany.todolist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
